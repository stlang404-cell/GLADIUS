THE ELO BLUEPRINT INTERACTIVE  (build 553953dd2761)
===============================================

An offline-capable chess trainer that accompanies the book: read the chapters,
solve the exercises with spaced repetition, play against a built-in engine,
analyse your games and turn your mistakes into personal review exercises.

RUN IT LOCALLY
--------------
Browsers do not run apps like this from a double-clicked file, so serve the folder:

  1. Open a terminal in this folder (THE-ELO-BLUEPRINT-INTERACTIVE).
  2. Run:   python3 -m http.server 8000
     (Windows: py -m http.server 8000)
  3. Open   http://localhost:8000/   in Chrome, Edge, Safari or Firefox.

Any static web server works; the folder can also be hosted under a sub-path
(for example https://example.com/app/). Make sure .wasm is served as
application/wasm (python's http.server does this).

INSTALL AS AN APP (works offline afterwards)
--------------------------------------------
  * iPhone/iPad (Safari): Share -> Add to Home Screen.
  * Android (Chrome): menu -> Install app / Add to Home screen.
  * Desktop Chrome/Edge: the install icon at the right of the address bar.
After the first visit everything (book, exercises, engine) is cached on the
device and the app works without a connection.

YOUR DATA
---------
Progress is stored only in this browser (localStorage). Nothing is uploaded.
Use More -> Settings & data -> Export progress to back it up or move it to
another device, and Import to restore it.

LICENCES
--------
Stockfish (stockfish.js 18, lite single-threaded build) is free software under
the GNU GPL v3; see vendor/stockfish/Copying.txt. Source code:
https://github.com/nmrugg/stockfish.js and https://github.com/official-stockfish/Stockfish
chess.js is BSD-2-Clause licensed (vendor/chess.js-LICENSE.txt).
Fonts (Source Serif 4, Cormorant Garamond, Inter) are under the SIL Open Font
Licence 1.1 (fonts/LICENSE-*.txt). Piece artwork is derived from DejaVu Sans
glyphs (Bitstream Vera / DejaVu licence).
